from django.shortcuts import render,get_object_or_404

# Create your views here.
from .models import *
from django.contrib.auth import authenticate , login ,logout
from django.contrib.auth.models import User
from django.conf import settings
from django.views import generic
from django.conf import settings
from django.http import HttpResponseRedirect
import os
import sweetify

def index(request):
	return render(request,'index.html',{})
def register(request):
	return render(request,'register.html',{})
def location(request):
	return render(request,'location.html',{})
def gallery(request):
	return render(request,'gallery.html',{})	
def	indexchat(request):
	return render(request,'indexchat.html',{})	

def signin(request):
	return render(request,'signin.html',{})		
def chat(request):
	return render(request,'chat.html',{})
def holiday(request):
	return render(request,'holiday.html',{})

def about(request):
	return render(request,'about.html',{})	
def signup(request):
	if request.method=='POST':
		name = request.POST.get('name')
		mobile = request.POST.get('mobile')
		password = request.POST.get('password')
		email = request.POST.get('email')

		user1=UserProfile.objects.filter(email=email,password=password).exists()
		if not user1:   
			user2=User.objects.create_user(
				username=email,
				password=password,
				)
			
			user_pro=UserProfile.objects.create(
				user=user2,
				name=name,
				email=email,
				password=password,
				mobile=mobile,
				
			)
			user_pro.save()
			return render(request,'signin.html',{"msg1":'you are logined'})
		else:
			error='you r already signed'
			return render(request,'index.html',{'error':error})


		# return render(request,'login.html',{"msg1":'you are logined'})
	else:
		return render(request,'index.html',{})
	return render(request,'index.html',{})
def log_in(request):
	if request.method == 'POST':
		email = request.POST.get('email')
		password = request.POST.get('password')
		user = authenticate(username=email,password=password)
		if user:
			print (user)

			login(request,user)
			return render(request,'indexchat.html', {"msg3":'Login Successfully'})
		else:
			
			return render(request,'index.html',{"msg2":'UNABLE TO LOGIN '})
	else:
		return render(request,'index.html',{})
	 
	return render(request,'index.html',{})
