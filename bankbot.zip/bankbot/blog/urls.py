from django.urls import path
from . import views
from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
   path('',views.index,name='index'),
   
   path('about/',views.about,name='about'),
   path('gallery/',views.gallery,name='gallery'),
   path('signup/',views.signup,name='signup'),
   path('log_in/',views.log_in,name='log_in'),
   path('chat/',views.chat,name='chat'),
   path('register/',views.register,name='register'),
   path('location/',views.location,name='location'),
   path('signin/',views.signin,name='signin'),
   path('holiday/',views.holiday,name='holiday'),
   path('indexchat/',views.indexchat,name='indexchat'),


  

]