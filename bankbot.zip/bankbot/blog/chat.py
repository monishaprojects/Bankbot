from nltk.chat.util import Chat, reflections
pairs = [
    [
        r"what is your name ?",
        ["My name is Bankbot and I can help you clear your banking queries ",]
    ],
     [
        r"Do you have branches in Thrissur?",
        ["Yes , we have a branch at MG Road, Thrissur.",]
    ],
    [
        r"what are the types of accounts you mainly have ?",
        ["We provide SB ,FD, accounts",]
    ],
    [
        r"How can I start a new SB account in you bank?",
        ["You can start an account by a visit to our nearest branch.",]
    ],
    [
        r"what is the rate of interest for an fd account in your bank ?",
        ["The rate of interest is 6.75 percentage  for and FD account.",]
    ],
    [
        r"Do you provide gold loans?",
        ["Yes, we do!",]
    ],
    [
        r"What is the interest rate for gold loan?",
        ["The interest rate for gold loan is 9 percentage  in our bank.",]
        
    ],
    [
        r"How many branches of this bank is present in India?",
        ["We have a total of 1144 branches all over India.",]
        
    ],
    [
        r"Which branch is nearest to me?",
        [" ",]
    ],
    [
        r"Which is the ATM nearest to me?",
        ['',]
    ],
    [
        r"Do you provide current account?",
        ["Yes we do."]
    ],
    [
        r"What is the rate of interest you provide for SB account?",
        ["SB account has 4 percentage  interest.",]
    ],
[
        r"Can I start a salary account here?",
        ["Yes ,you can."]
    ],
    [
        r"Do you provide online banking services?",
        ["Yes ,we provide online banking services for requested users. ",]
    ],
    [
        r"Do you have a banking app for android phones?",
        ["Yes , we have an app for the ease of mobile users.",]
    ],
    [
        r"How to get cheque facility?",
        ["Kindly send a cheque request to the bank."]
],
    [
        r"Is it compulsory to add a nominee for my SB account?",
        ["No .It is not compulsory."]
],
[r"Can I start RD account?",
["Yes , you can start an RD account using online application or visit branch.",]
],
[r"What is the rate of interest of RD account?",
["The rate of interest of RD account is 6.5 %"]
],
[r"What is the eligibility of getting a home loan?",
["Visit nearest branch with salary slip.",]
],
[r"Do you have car loan facility?",
["Yes, we provide car loans.",]
],
[r"What is the car loan interest rate?",
["The car loan interest rate is 7.4%.",]
],
[r"(.*)?",
[".",]
],
[r"(.*)?",
[".",]
],


    [
        r"quit",
        ["Bye take care. See you soon :) ","It was nice talking to you. See you soon :)"]
],
]
def chatty():
    print("Hi, I'm Chatty and I chat alot ;)\nPlease type lowercase English language to start a conversation. Type quit to leave ") #default message at the start
    chat = Chat(pairs, reflections)
    chat.converse()
if __name__ == "__main__":
    chatty()